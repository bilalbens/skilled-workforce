package com.skilled.workforce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkilledWorkforceApp {

	public static void main(String[] args) {
		SpringApplication.run(SkilledWorkforceApp.class, args);
	}

}
